<?php
	session_start();
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
			header('location:login.php');
	}
?>
<!doctype html>
<html lang="en">
 <?php include_once('template/top-header.php');?>
 <body> <!-- onContextMenu="return false" -->
<?php include_once ('template/head.php')?>
<div class="container">
  <br/>
  <br/>
  <br/>
  <div class="row" id="offbar">
    <div class="col-md-9"style= "borde-top: 0px;">
		<div class="col-sm-12">
			<div class="card-body">
				<div class="card text-center">
				  <h3><div class="card-header">
				    <p style="font-family: cooper;">IMPORT PAYSLIP PDF FILE AND SPLIT </p>
				  </div></h3>
				  	<div class="container">
					  <div class="row">
					    
					    <div class="col-sm-8">
					    	<center><div id="error" class="error"></div></center>
					      <div class="card-body" id="formContainer">
					      	
				<form id="fupForm" method="post">
					<center><h5><i class="fa fa-upload"></i> Upload Payslip PDF File</h5></center>
					<a href="#" id="flipToLogin" class="flipLink"><i class="fa fa-right"></i></a>
					<br/>
					<br/>
					<div class="form-group">
						<select name="date_name" class="form-control">
							<option>--Select Date--</option>
							<?php 
								include_once('connection.php');
								$getdates = mysqli_query($connect,"select * from payslip_dates");
								while($datelist = mysqli_fetch_array($getdates)){
								?>
							<option value="<?php echo $datelist['date_name'];?>"><?php echo $datelist['date_name'];?></option>
							<?php } ?>
						</select>
					</div>

					<div class="form-group">
						 <label for="exampleFormControlFile1">Choose Payslip File</label>
						<input type="file" name="payslip_file" id="payslip_file" class="form-control-file">
					</div>
					<div class="form-group">
						<button  name="submit" class="btn btn-success btn-block btn-payslip" id="admworking"> <i class="fa fa-sign-in"></i> Upload </button>
					</div>	
				</form>
				
				
				<form id="split-process" method="post"  onsubmit="return do_splitting();">
					<center><h5 class="card-title"><i class="fa fa-gear"></i>Split payslip into individual page</h5></center>
					<a href="#" id="flipToRecover" class="flipLink"><i class="fa fa-arrow"></i></a>
					<br/>
					<br/>
					<?php 
					    include_once('connection.php');
					    if(isset($_POST['date_name'])){
					    	$date_name = $_POST['date_name'];
					    	$getpayslipfile = mysqli_query($connect,"select * from payslip_report where payslip_date ='".$date_name."'");
							$payslip_pdf = mysqli_fetch_array($getpayslipfile);
					    }
						
					?>
					<div class="form-group">
						<select name="date_name" class="form-control" onchange='if(this.value !=0){this.form.submit();}'>
							<option>--Select Date--</option>
							<?php 
								include_once('connection.php');
								$getdates = mysqli_query($connect,"select * from payslip_dates");
								while($datelist = mysqli_fetch_array($getdates)){
									  	$newdate = $datelist['date_name'];
										if (@$_POST['date_name'] == $newdate) {

												echo "<option value=\"".$newdate."\" selected='selected'>".$newdate."</option>"; 
											} else {
												echo "<option value=\"".$newdate."\">".$newdate."</option>";       
											}
								?>
							
							<?php } ?>
						</select>
					</div>
					
					<input type="hidden" name="file_name" id="file_name" value="<?php if(isset($payslip_pdf['payslip_name'])){ echo $payslip_pdf['payslip_name'];}?>">

					<div class="form-group">
						<button  name="btnSplitter" class="btn btn-success btn-block btn-payslip" id="working"><i class="fa fa-sign-in"></i> Start Process </button>
					</div>	
				</form>
				<br>
				    	   <center><img src="images/process_splitter.gif" height="100" width="200" class="processing_spinner"></center>
				    	  </div>
				    	  <br>
				    	  <br>
					    </div>
						<?php include_once('template/payslipmenu.php');?>
					  </div>
					 </div>
					 
				  </div>
				  
					 
			</div>
		</div>
	</div>
		<?php include_once('template/menu.php')?>
  </div><!--End of Row-->
  <hr>
					
			<fieldset class="scheduler-border">
				<legend class="scheduler-border">Select a staff payslips and send to His/Her Email</legend>
					  <div class="row">
					  		
					  	
					  	<?php
					    $www_root = 'http://localhost/payslipsystem/converted';
					    $dir = 'converted';
					    $file_display = array('jpg', 'jpeg', 'png', 'gif');

					    if ( file_exists( $dir ) == false ) {
					       echo 'Directory \''. $dir. '\' not found!';
					    } else {
					       $dir_contents = scandir( $dir );

					        foreach ( $dir_contents as $file ) {
					           @$file_type = strtolower( end( explode('.', $file ) ) );
					           if ( ($file !== '.') && ($file !== '..') && (in_array( $file_type, $file_display)) ) {
					            ?>

					           <div class="col-sm-6 box">
					   <form id="send_mail" method="post">
						  <div class="form-row align-items-center">
						    <div class="col-auto my-1">
						<select id="selectpicker" name="staffemail" class="form-control mr-sm-2 selectpicker members-select"  data-live-search="true">
						        <option value="">Choose This Staff</option>
                           <?php 
                              include_once('connection.php');
                              $getstafflist = mysqli_query($connect,"select * from employees");
                              while($stafflist = mysqli_fetch_array($getstafflist)){
                              ?>
                                 <option value="<?php echo $stafflist['email'];?>"><?php echo $stafflist['firstname']." ".$stafflist['surname']." ".$stafflist['othername'];?></option>
                              
                            <?php } ?>
                           
						</select>
						    </div>
						    <div class="col-auto my-1">
						      <div class="custom-control custom-checkbox mr-sm-2">
						       <button type="button" class="btn btn-primary members-select payslip_button" name="email_button" data-email="<?php echo $stafflist['email'];?>" data-name="<?php echo $stafflist['surname'];?>" data-placement="bottom" data-action="single" title="Send to mail"><i class="fa fa-send"></i></button>
						      </div>
						    </div>
						    <div class="col-auto my-1">
						      <button type="submit" class="btn btn-danger members-select" data-toggle="tooltip" data-placement="bottom" title="Remove"><i class="fa fa-trash"></i></button>
						    </div>
						     <div class="col-auto my-1">
						    <input type="checkbox" name="single_select" class="single_select" data-email="<?php echo $row["email"]?>" data-name="<?php echo $row["surname"]?>" />
							</div>
						  </div>
						</form>
					    		<div class="card">

					              <img src=<?php echo $www_root. '/'. $file;?> alt=<?php echo $file;?> class="payslip zoom"/>
						           </div>
						           <br><br>
						       </div>
					           <?php
					           //break;
					           }
					        }
					    }
					?>
					
					  </div>
				</fieldset>
					
</div>
<footer>
  <p style="text-align: center;">&copy; 2020 | ICT/MIS Directorate, FPTB </p>
</footer>
<script type="text/javascript" src="js/jquery.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('.selectpicker').selectpicker();
	})
</script>
<script type="text/javascript">
	function do_splitting()
		{
		 //var username=$("#username").val();
		 var file_date = $("#file_date").val();
		 var file_name = $("#file_name").val();
		 if(file_date!="" && file_name!="")
		 {
		  $(".processing_spinner").css({"display":"block"});
		  $.ajax
		  ({
		  type:'post',
		  url:'splitpayslips.php',
		  data:{
		   btnSplitter:"btnSplitter",
		   file_name:file_name
		  },
		  success:function(response) {
		  if(response=="OK")
		  {
			//window.location.href="dashboard.php";
			$("#error").css({"display":"none"});
			window.location.href ="managepayslip.php";
			//setTimeout('window.location.href ="dashboard.php"; ',3000);
		  }
		  else
		  {
			$(".processing_spinner").css({"display":"none"});
			//alert("Wrong Details");
			$("#error").html('<div class="alert alert-danger">An error occure while processing. Please try again</div>');
		  }
		  }
		  });
		 }
		 else
		 {
		  //alert("Please Fill All The Details");
		  $("#error").html('<div class="alert alert-danger">Please select date</div>');
		 }
		 return false;
		}
</script>
<script type="text/javascript">
	$(document).ready(function(e){
    // Submit form data via Ajax
    $("#fupForm").on('submit', function(e){
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'upload_payslip.php',
            data: new FormData(this),
            dataType: 'json',
            contentType: false,
            cache: false,
            processData:false,
            beforeSend: function(){
                $('.btn-payslip').attr("disabled","disabled");
                $('#fupForm').css("opacity",".5");
            },
            success: function(response){ //console.log(response);
                $('.error').html('');
                if(response.status == 1){
                    $('#fupForm')[0].reset();
                    $('.error').html('<div class="alert alert-success">'+response.message+'</div>');
                }else{
                    $('.error').html('<div class="alert alert-danger">'+response.message+'</div>');
                }
                $('#fupForm').css("opacity","");
                $(".btn-payslip").removeAttr("disabled");
            }
        });
    });
});
</script>
<script>
$(document).ready(function(){
	$('.payslip_button').click(function(){
		$(this).attr('disabled', 'disabled');
		var id  = $(this).attr("id");
		var action = $(this).data("action");
		var email_data = [];
		if(action == 'single')
		{
			email_data.push({
				email: $(this).data("email"),
				name: $(this).data("name")
			});
		}
		else
		{
			$('.single_select').each(function(){
				if($(this).prop("checked") == true)
				{
					email_data.push({
						email: $(this).data("email"),
						name: $(this).data('name')
					});
				} 
			});
		}

		$.ajax({
			url:"send_payslip.php",
			method:"POST",
			data:{email_data:email_data},
			beforeSend:function(){
				$('#'+id).html('<div class="spinner-grow text-light" role="status"><span class="sr-only">Loading...</span></div>');
				/*$('#'+id).addClass('btn-default');*/
			},
			success:function(data){
				if(data == 'ok')
				{
					$('#'+id).text('Success');
					/*$('#'+id).removeClass('btn-default');*/
					$('#'+id).removeClass('btn-primary');
					$('#'+id).addClass('btn-success');
				}
				else
				{
					$('#'+id).text(data);
				}
				$('#'+id).attr('disabled', false);
			}
		})

	});
});
</script>

<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>

</body> 
</html>