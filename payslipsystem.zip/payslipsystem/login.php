<?php
	session_start();
?>
<!Doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>FPTB - Payslip Mailing System</title>
	
  </head>
<body>
	<?php include_once ('template/head.php')?>
	<div class="container">
  		<div class="row">
    		<div class="col-sm">
      			<div class="container">
				  <div class="row">
				    <div class="col-md-6" style="border-right:1px solid #f5f5f5;border-width:thin;">
				     <form id="login_form" action="checklogin.php" method="post" onsubmit="return do_login();">	
				    	<div class="card border-0">
					      <div class="card-body">
					      	<!-- <img src="images/polylogo.jpg" style="width: 30px; height: 30px;" alt="..."> FPTB STAFF PAYSLIP MAILLING SYSTEM -->
				    	<br>
				    	<br>
				    	
				    	<div class="d-flex align-items-center" >
						  <span class="loading_spinner">Loading...</span>
						  <div  class="spinner-border text-primary ml-auto loading_spinner" role="status" aria-hidden="true"></div>
						</div>
						<center><div id="error"></div></center>
						<br>
					        <h5 class="card-title" style="font-size: 12px;">SIGN IN</h5>
					      
						  <div class="form-group">
						    <!-- <label for="exampleInputUsername">Email address</label> -->
						    <input type="username" name="username" id="username" class="form-control form-control-sm" autocomplete="off" placeholder="Username..." id="exampleInputUsername" aria-describedby="userHelp">
						  </div>
						  <div class="form-group">
						    <!-- <label for="exampleInputPassword1">Password</label> -->
						    <input type="password" name="password" id="password" class="form-control form-control-sm" placeholder="Password..." id="exampleInputPassword1">
						  </div>
						  <div class="form-group form-check">
						    <input type="checkbox" class="form-check-input" id="exampleCheck1">
						    <label class="form-check-label" for="exampleCheck1">Remember me </label>
						  </div>
						  <div class="form-group">
						  	 <button type="submit" class="btn btn-primary btn-block btn-sm">Log-In</button>
						  </div>
						  <div class="form-group">
						  	<h2 class="legend"><span><a href="#">Need Help?</a></span></h2>
						  </div>
						 <!--  <div class="text-center">
							  <div class="spinner-border text-primary" role="status">
							    <span class="sr-only">Loading...</span>
							  </div>
							</div> -->
						</form>
					      </div>
					    </div>
				    	
					</div>
					<div class="col-md-6 leftside">
				    	<div class="card mb-3 border-0">
						  <img src="images/payslipphoto.jpg" class="card-img-top" alt="...">
						  <div class="card-body">
						   <div class="jumbotron jumbotron">
							  <div class="container">
							    <h4 class="display-6"></h4>
							    <p class="lead">This system is designed to sent IPPIS generated payment slip to FPTB staff e-mail address, where a staff can print his payslip at anytime.</p>
							  </div>
							</div>
						  </div>
						</div>

				    	
				    </div>
				  </div>
				</div>
    		</div>
    	</div>
	</div>
<html lang="en">
  <?php include_once ('template/footer.php')?>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
		function do_login()
		{
		 var username=$("#username").val();
		 var password=$("#password").val();
		 if(username!="" && password!="")
		 {
		  $(".loading_spinner").css({"display":"block"});
		  $.ajax
		  ({
		  type:'post',
		  url:'checklogin.php',
		  data:{
		   btnLogin:"btnLogin",
		   username:username,
		   password:password
		  },
		  success:function(response) {
		  if(response=="success")
		  {
			//window.location.href="dashboard.php";
			$("#error").css({"display":"none"});
			setTimeout('window.location.href ="dashboard.php"; ',3000);
		  }
		  else
		  {
			$(".loading_spinner").css({"display":"none"});
			//alert("Wrong Details");
			$("#error").html('<div class="alert alert-danger">Invalid Username or Password</div>');
		  }
		  }
		  });
		 }

		 else
		 {
		  //alert("Please Fill All The Details");
		  $("#error").html('<div class="alert alert-danger">Please enter username and password</div>');
		 }

		 return false;
		}
</script>
</body>
</html>
