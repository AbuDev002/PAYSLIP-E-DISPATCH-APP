<?php
	//create imagick
	$imagick = new Imagick();
	//set the image resolution
	$imagick->setResolution(300, 300);
	//read image from PDF
	$imagick->readImage('C:\xampp\htdocs\payslipsystem\dummy.pdf[0]');
	$imagick->setImageFormat('jpg');
	header('Content-Type: image/jpeg');
	//Merge a sequence of images
	//$imagick = $imagick->flattenImages();
	//writes an image
	$imagick->writeImages('converted/converted.png',false);

	echo $imagick;
?>


<?php
	// //create imagick
	// $imagick = new Imagick();
	// //set the image resolution
	// //$imagick->setResolution(300, 300);
	// //read image from PDF
	// $imagick->readImage('C:\xampp\htdocs\payslipsystem\dummy.pdf');
	// //$imagick->setImageFormat('jpg');
	// //header('Content-Type: image/jpeg');
	// //Merge a sequence of images
	// //$imagick = $imagick->flattenImages();
	// //writes an image
	// $imagick->writeImages('converted.png',false);

	// echo $imagick;
?>
<?php

    $pathToPdf = realpath("dummy.pdf");

    //$pathToJpg = "converted/out.jpg";
    $pathToPng = "converted/out.png";

    try
        {

        // $time_start = microtime(true);      
        // $gsCall = "\"C:\Program Files (x86)\gs\gs9.06\bin\gswin32.exe\" -q -dBATCH -dMaxBitmap=300000000 -dNOPAUSE -dSAFER -sDEVICE=jpeg -dTextAlphaBits=4 -dGraphicsAlphaBits=4 -dFirstPage=1 -dLastPage=1 -sOutputFile=\"{0}\" \"{1}\" -c quit";
        // $gsCall = str_replace(array('{0}', '{1}'), array($pathToJpg, $pathToPdf), $gsCall); // or use sprintf
        // $str = exec($gsCall, $output=array(), $returnValue);
        // echo $gsCall.'<br><br>';
        // $time_end = microtime(true);
        // $time = $time_end - $time_start;        
        // if($returnValue == 0)              
        //     print "<br><br>Conversion OK ".$time;
        // else 
        //     print "<br><br>Conversion failed.<br />".var_dump($output);     

        $time_start = microtime(true);          
        exec('convert "'.$pathToPdf.'[0]" "'.$pathToPng.'"', $output, $returnValue);                        
        $time_end = microtime(true);
        $time = $time_end - $time_start;
        if($returnValue == 0)              
            print "<br><br>Conversion OK ".$time;
        else 
            print "<br><br>Conversion failed.<br />".var_dump($output);

        $time_start = microtime(true);
        $im = new Imagick($pathToPdf);
        $im->setIteratorIndex(0);
        $im->setCompression(Imagick::COMPRESSION_LZW);
        $im->setCompressionQuality(90);
        $im->setImageFormat("png");
        $im->writeImage('\\\\DELL-PC\Shared\test.png');
        //$im->thumbnailImage(200, 0);
        //echo $im;
        $time_end = microtime(true);
        $time = $time_end - $time_start;
        print "<br><br>Conversion OK ".$time;
    }
catch(Exception $e)
{
    echo $e->getMessage();
}
?>


<?php
$reachedLastPage = false;
for ($i = 0; $i <= 10 && empty($reachedLastPage); $i++) {
    $im = new imagick();
    $im->setResolution(300,300);
    try {
        $im->readimage($tempFile.'['.$i.']');
        if ($im->valid()) {
            $im->setImageBackgroundColor('white');
            $im->setImageAlphaChannel(Imagick::VIRTUALPIXELMETHOD_WHITE);
            $im->setImageCompression(imagick::COMPRESSION_JPEG);
            $im->setImageCompressionQuality(60);
            $im->setImageFormat('jpeg');

            $extraFile = microtime(true).'__pdfpage'.".".strtolower('jpg');
            $im->writeImage(rtrim($targetPath) . $extraFile);

            if (is_file(rtrim($targetPath) . $extraFile)) {
                $imageArray[] = $extraFile;
            }
        }
    }
    catch(ImagickException $e) {
        $reachedLastPage = true;
    }
    $im->clear();
    $im->destroy();
}
?>


//viewing image from a file and display in browser
<?php
    $www_root = 'http://localhost/images';
    $dir = '/var/www/images';
    $file_display = array('jpg', 'jpeg', 'png', 'gif');

    if ( file_exists( $dir ) == false ) {
       echo 'Directory \'', $dir, '\' not found!';
    } else {
       $dir_contents = scandir( $dir );

        foreach ( $dir_contents as $file ) {
           $file_type = strtolower( end( explode('.', $file ) ) );
           if ( ($file !== '.') && ($file !== '..') && (in_array( $file_type, $file_display)) ) {
              echo '<img src="', $www_root, '/', $file, '" alt="', $file, '"/>';
           break;
           }
        }
    }
?>