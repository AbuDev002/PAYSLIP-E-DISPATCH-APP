<?php
	session_start();
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
			header('location:login.php');
	}
?>
<!doctype html>
<html lang="en">
 <?php include_once('template/top-header.php');?>
 <body>
<?php include_once ('template/head.php')?>
<div class="container">
  <br/>
  <div class="row">
    <div class="col-md-9"style= "borde-top: 0px;">
		<div class="col-sm-12">
			<div class="card-body">
				<div class="jumbotron jumbotron">
					<div class="container">
						<fieldset class="scheduler-border">
					<legend class="scheduler-border">Staff List Upload (CSV Only)</legend>
					<div class="row">
		<div class="col-md-12">
			<?php include_once('template/upload_stafflist.php');?>
			<?php echo $error_msg; ?>
			<form action="" method="POST" enctype="multipart/form-data">
			  <div class="form-row align-items-center">
				<div class="col-auto my-1">
					 <input type="file" name="upload1" class="form-control-file" id="exampleFormControlFile1">
				</div>
				<div class="col-auto my-1">
				  
				  <select name="dept_id" class="form-control selectpicker" id="selectpicker" data-live-search="true">
					<option>Choose Department</option>
					<?php 
					  include_once('connection.php');
					  $getdept_units = mysqli_query($connect,"select * from department_units");
					  while($dept_list = mysqli_fetch_array($getdept_units)){
							$dept_id = $dept_list['id'];
							$dept_name = $dept_list['unit'];
					  if (@$_GET['department_list'] == $dept_id) {

						echo "<option value=\"".$dept_id."\" selected='selected'>".$dept_name."</option>"; 
						} else {
							echo "<option value=\"".$dept_id."\">".$dept_name."</option>";       
						}
					}	
					  ?>
				  </select>
				</div>
				<div class="col-auto my-1">
				  <button type="submit" name="btnUploadStaffs" class="btn btn-primary">Upload</button>
				</div>
			  </div>
			</form>
		</div>
		
	</div>
				</fieldset>
					</div>
				</div>
				
			</div>
		</div>
		 <!--<p style="text-align: center;"><small>&copy; 2020 | ICT/MIS Directorate, FPTB</small> </p>-->
		<?php include_once('template/footer.php')?>
	</div>
  <?php include_once('template/menu.php')?>
  </div>
  <!-- <footer >
 
</footer> -->
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
 <script src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
 <script src="js/bootstrap-select.min.js"></script>
<script src="js/alertify.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="js/responsive.bootstrap4.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.selectpicker').selectpicker();
	
  })
</script>

</body> 
</html>