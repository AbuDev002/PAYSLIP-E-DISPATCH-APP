<?php
	if(isset($_POST['btnSplitter'])){
		$file_name = $_POST['file_name'];
	    $pathToPdf = realpath($file_name);
	    //$pathToJpg = "converted/out.jpg";
	    $pathToPng = "converted/payslipfile.png";
    try
        {
        //$time_start = microtime(true);          
        exec('convert "'.$pathToPdf.'" "'.$pathToPng.'"', $output, $returnValue);                        
        //$time_end = microtime(true);
        //$time = $time_end - $time_start;
        if($returnValue == 0)              
            echo "OK";//.$time;
        else 
            echo "Failed";//.var_dump($output);

    }
catch(Exception $e)
{
    echo $e->getMessage();
}
}
?>