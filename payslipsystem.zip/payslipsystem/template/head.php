<!-- <div class="card text-center" id="navbar" style="border-top:0px;">
  <div class="card-header">
    <h3>FEDERAL POLYTECHNIC, BAUCHI</h3> 
	<h5 class="card-title">PAYMENT SLIP PROCESSING SYSTEM</h5>
  </div>
</div> -->
<!-- Image and text -->
<nav class="navbar navbar-light bg-light">
  <a class="navbar-brand" href="#">
    <img src="images/polylogo.jpg" width="30" height="30" class="d-inline-block align-top" alt="" loading="lazy">
    FPTB PAYSLIP E-DISPATCH SYSTEM
  </a>
</nav>