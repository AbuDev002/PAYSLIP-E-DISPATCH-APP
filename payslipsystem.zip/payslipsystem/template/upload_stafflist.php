<?php
	include('connection.php');
	
		$error_msg ="";
	if(isset($_POST['btnUploadStaffs'])){
		@$ippis_no = $_POST['ippis_no'];
		@$surname = $_POST['surname'];
		@$firstname = $_POST['firstname'];
		@$othername = $_POST['othername'];
		@$email = $_POST['email'];
		@$dept_id = $_POST['dept_id'];
		@$file1 = $_FILES['upload1'] ['tmp_name'];
		//$file2 = $_FILES['upload2'] ['tmp_name'];
	
		if($file1){
		$handle = fopen($file1,"r");
		
		while(($fileop = fgetcsv($handle,1000,",")) !== false){
				$ippis_no = $fileop[0];
				$surname = $fileop[1];
				$firstname = $fileop[2];
				$othername = $fileop[3];
				$email = $fileop[4];
				//$dept_id = $fileop[5];
				
				
			$query = mysqli_query($connect,"INSERT INTO employees (ippis_no,surname,firstname,othername,email,dept_id) VALUES('".mysqli_real_escape_string($connect,$ippis_no)."','".mysqli_real_escape_string($connect,$surname)."','".mysqli_real_escape_string($connect,$firstname)."','".mysqli_real_escape_string($connect,$othername)."','".mysqli_real_escape_string($connect,$email)."',".$dept_id.")") or die('Upload failed');
		
		}
			if($query){
					$error_msg ='<p class="alert alert-success">Uploaded successfully.</p>';
			}
		}else{
				$error_msg ='<p class="alert alert-warning">Please select your list</>';
		}
	}


?>