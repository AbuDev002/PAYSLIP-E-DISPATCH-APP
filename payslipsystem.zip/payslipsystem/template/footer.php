<footer>
  <p style="text-align: center;"> <small>&copy; <?php echo date("Y")?> | All rights reserved ICT/MIS Directorate </small></p>
</footer>