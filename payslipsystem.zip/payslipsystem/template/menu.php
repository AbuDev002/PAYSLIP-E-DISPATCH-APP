<div class="col-md-3">
	<fieldset class="scheduler-border" id="operation_menu">
		<legend class="scheduler-border">Operational Menu</legend>
		<ul class="list-group list-group-flush">
			<li class="list-group-item"><a href="dashboard.php"> <i class="fa fa-home"></i>  Dashboard</a></li>
			<li class="list-group-item"><a href="stafflistupload.php" id="specialLink"><i class="fa fa-upload"></i> Upload staff list</a></li>
			<li class="list-group-item"><a href="splitapp.php" id="specialLink"><i class="fa fa-gear"></i> Run Splitter</a></li>
			<li class="list-group-item"><a href="uploadallpayslip.php"><i class="fa fa-gear"></i> Manage Payslip</a></li>
			<li class="list-group-item"><a href="employee.php"> <i class="fa fa-users"></i> Payslip/Email</a></li>
			<!-- <li class="list-group-item"><a href="#"><i class="fa fa-file"></i> Reports</a></li> -->
			<li class="list-group-item"><a href="logout.php" ><i class="fa fa-sign-out"></i> Sign Out</a></li>
	</ul>
	</fieldset>
</div>

<!--<script>
	document.getElementById("specialLink").onclick = function() {
		// add code here
		var my_var = <?php //exec('C:\Program Files (x86)\A-PDF Content Splitter\PdfCS.exe');?>;
	}
</script>-->
