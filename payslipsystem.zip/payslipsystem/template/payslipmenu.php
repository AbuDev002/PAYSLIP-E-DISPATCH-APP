<div class="col-sm-4">
	<a href="managepayslip.php" class="btn btn-success btn-block">Split & Email Payslip</a>
	<a href="paysliplist.php" class="btn btn-primary btn-block">List of Payslips</a>
	<a href="uploadallpayslip.php" class="btn btn-dark btn-block">Upload All Payslips</a>
	<a href="recyclefiles.php" class="btn btn-danger btn-block"><i class="fa fa-trash"></i> Clear Files</a>
</div>