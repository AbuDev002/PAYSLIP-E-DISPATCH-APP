<?php 
	echo exec('C:\Program Files (x86)\A-PDF Content Splitter\PdfCS.exe');
	header("location:dashboard.php");
?>