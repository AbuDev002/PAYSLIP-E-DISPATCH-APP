<!-- Modal -->
<div class="modal new-member-modal" id="membersModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">STAFF REGISTRATION FORM</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <!--  <center><h5 class="card-title">APPLICANT DETAILS</h5></center> -->
               
        <form method="post" id="addmember_form">
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                    <div class="col-md-6">
                       <label> Staff ID</label>
                      <div class="form-group">
                          <input type="text" name="staffno" id="staffno" class="form-control" placeholder="PFN Number" />
                      </div>

                      <label>IPPIS No.</label>
                      <div class="form-group">
                          <input type="text" name="ippisno" id="ippisno" class="form-control" placeholder="IPPIS No." />
                      </div>

                       <label> Firstname </label>
                      <div class="form-group">
                          <input type="text" name="firstname" id="firstname" class="form-control" placeholder="Firstname..." />
                      </div>

                       <label> Surname </label>
                      <div class="form-group">
                          <input type="text" name="surname" id="surname" class="form-control" placeholder="Surname..." />
                      </div>

                      
                    </div>
                    <div class="col-md-6">
                       <label> Othername </label>
                      <div class="form-group">
                          <input type="text" name="othername" id="othername" class="form-control" placeholder="Othername..." />
                      </div>
                       <div class="form-group">
                          <label class="my-1 mr-2"  for="gender">Gender</label>
                          <select class="form-control" name="gender" id="gender">
                              <option>--Select--</option>
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                          </select>
                      </div>

                      <label>Phone Number</label>
                      <div class="form-group">
                          <input type="text" class="form-control" name="phoneno" id="phoneno" placeholder="Phone Number" />
                      </div>
                       <label>Email <small style="color:red;">(Only @fptb.edu.ng allowed)</small></label>
                      <div class="form-group">
                          <input type="email" class="form-control" pattern=".+@fptb.edu.ng" name="email" id="email" placeholder="Email address..." />
                      </div>
                      <div class="form-group">
                          <label for="department">Departments</label>
                           <select name="department" class="form-control selectpicker" data-live-search="true" style="background: #fff;" id="selectpicker">
                                     
                                     <option>Choose Department</option>
                                     <?php 
                                        include_once('connection.php');
                                        $getdept_units = mysqli_query($connect,"select * from department_units");
                                        while($dept_list = mysqli_fetch_array($getdept_units)){
                                        ?>
                                           <option value="<?php echo $dept_list['id'];?>"><?php echo $dept_list['unit'];?></option>
                                    <?php }?>
             
                            </select>
                      </div>
                    </div>
                </div> 
                    </div>
                  </div>
                    
               
            </div>
            <div class="modal-footer">
                <input type="hidden" name="member_id" id="member_id" /> 
                <input type="submit" value="Save Member" name="btnAddMember" id="btnAddMember" class="btn btn-primary btn-block">
            </div>
        </form>
        </div>
    </div>
</div>
