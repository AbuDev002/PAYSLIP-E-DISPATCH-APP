<?php
	session_start();
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
			header('location:login.php');
	}
?>
<!doctype html>
<html lang="en">
 <?php include_once('template/top-header.php');?>
 <body onContextMenu="return false"> <!-- onContextMenu="return false" -->
<?php include_once ('template/head.php')?>
<div class="container">
  <br/>
  <div class="row">
    <div class="col-md-9"style= "borde-top: 0px;">
		<div class="col-sm-12">
			<div class="card-body">
				<div class="card text-center">
				  <h3>
				  	<div class="card-header">
				    <p style="font-family: cooper;">IMPORT PAYSLIP PDF FILE AND SPLIT </p>
				  </div>
				</h3>
				  	<div class="container">
					  <div class="row">
					    
					    <div class="col-sm-8">
					    	<center><div id="error" class="error"></div></center>
					    	<table class="table table-striped table-bordered">
					    		<tr>
					    			<th>S/N</th>
					    			<th>Date</th>
					    			<th>Payslip File</th>
					    		</tr>
					    		<?php
					    			include_once('connection.php');
					    		    $sn = 0;
					    			$getpayslips = mysqli_query($connect,"select * from payslip_report");
					    			while($paysliplist = mysqli_fetch_array($getpayslips)){
					    				$sn++;
					    		?>
					    		<tr>
					    			<td><?php echo $sn;?></td>
					    			<td><?php echo $paysliplist['payslip_date']?></td>
					    			<td><?php echo $paysliplist['payslip_name']?></td>
					    		</tr>
					    		<?php
					    			}
					    		?>
					    		
					    	</table>
				    	  <br>
				    	  <br>


				    	  <?php
				    	  	if (!extension_loaded('imagick')){
    echo 'imagick not installed';
}
				    	  ?>
					    </div>
						<?php include_once('template/payslipmenu.php');?>
					  </div>

					 </div>
					 
				  </div>
				  
					 
			</div>
		</div>
	</div>
		<?php include_once('template/menu.php')?>
  </div>
		
</div>
<footer>
  <p style="text-align: center;">&copy; 2020 | ICT/MIS Directorate, FPTB </p>
</footer>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</body> 
</html>