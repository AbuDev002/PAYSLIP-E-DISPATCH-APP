<?php
	session_start();
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
			header('location:login.php');
	}
?>
<!doctype html>
<html lang="en">
   <?php include_once('template/top-header.php');?>
 <body>
<?php include_once ('template/head.php')?>

<div class="container">
	<br>
	
	<div class="row">
	<div class="col-md-9">
	<ul class="nav justify-content-end">
	  <li class="nav-item">
		<a class="nav-link target-member" id="addNewMember" href="#" data-target="#membersModal"><i class="fa fa-plus"></i> Add New Staff</a>
	  
	  </li>
	</ul>

								<div class="card border-0">
									<div class="card-header" style="background: #F0F0F0;">
										<h5 class="card-title">STAFF LIST AND EMAIL DISPATCHING</h5>
									</div>
									<div class="card">
										<div class="card-body">
											<form>
												<div class="row">
												<div class="col-md-4">
													<div class="form-group">
														<label>Select Payslip Month</label>
														<input type="month" name="payslipmonth" class="form-control" id="payslpmonth" value="<?php if(isset($_GET['payslipmonth'])){ echo $_GET['payslipmonth'];}?>">
													</div>
												</div>
												<div class="col-md-4">
													 <div class="form-group">
													 <label>Choose Department</label> 
					                        <select id="selectpicker" class="form-control selectpicker" name="department_list" onchange='if(this.value !=0){this.form.submit();}'  data-live-search="true" style="background: #fff;">
					                           
					                           <option value="">Choose Department</option>
       <?php 
          include_once('connection.php');
          $getdept_units = mysqli_query($connect,"select * from department_units");
          while($dept_list = mysqli_fetch_array($getdept_units)){
          		$dept_id = $dept_list['id'];
          		$dept_name = $dept_list['unit'];
          if (@$_GET['department_list'] == $dept_id) {

			echo "<option value=\"".$dept_id."\" selected='selected'>".$dept_name."</option>"; 
			} else {
				echo "<option value=\"".$dept_id."\">".$dept_name."</option>";       
			}
		}	
          ?>
       
					                        </select>
                      </div>
												</div>
												<div class="col-md-4">
													<button type="submit" class="btn btn-primary" style="margin:30px;">Get List</button>
												</div>
											</div>
											</form>
										</div>
									</div>
										
								<!-- <div class="card"> -->
								<div class="card-body" id="loadstafflist" style="overflow:auto;width:100%;">
								  <center><img src="images/h_loader.gif" id="h_loader" style="display: none;"></center>
									
								</div>
								<!-- </div> -->	
												
								</div>
							</div>
				<?php include_once ('template/menu.php')?>
						</div>
</div>
<?php include_once('modals/members/members_add.php')?>
<?php include_once('modals/members/members_details.php')?>
<?php include_once('template/footer.php')?>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
 <script src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
 <script src="js/bootstrap-select.min.js"></script>
<script src="js/alertify.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="js/responsive.bootstrap4.min.js"></script>
<script type="text/javascript" src="js/datatablebuttons.min.js"></script>

<script>
	function SendPayslip(){
	//$(document).ready(function(){
	$('.email_button').click(function(){
		$(this).attr('disabled', 'disabled');
		var id  = $(this).attr("id");
		var action = $(this).data("action");
		var email_data = [];
		if(action == 'single')
		{
			email_data.push({
				email: $(this).data("email"),
				name: $(this).data("name"),
				payslip: $(this).data('payslip'),
        pmonth: $(this).data('pmonth')
			});
		}
		else
		{
			$('.single_select').each(function(){
				if($(this).prop("checked") == true)
				{
					email_data.push({
						email: $(this).data("email"),
						name: $(this).data('name'),
						payslip: $(this).data('payslip'),
            pmonth: $(this).data('pmonth')
					});
				} 
			});
		}

		$.ajax({
			url:"send_mail.php",
			method:"POST",
			data:{email_data:email_data},
			beforeSend:function(){
				$('#'+id).html('<div class="spinner-grow text-light" role="status"><span class="sr-only">Loading...</span></div>');
				/*$('#'+id).addClass('btn-default');*/
			},
			success:function(data){
				if(data == 'ok')
				{
					$('#'+id).html('<i class="fa fa-check"></i>');
					/*$('#'+id).removeClass('btn-default');*/
					alertify.set('notifier','position', 'top-center');
                 	alertify.success('Email Sent...');  
					$('#'+id).removeClass('btn-info');
					$('#'+id).addClass('btn-success');
				}
				else
				{
					$('#'+id).text(data);
				}
				$('#'+id).attr('disabled', false);
			}
		})

	});
//});
}
</script>

<script>  
 $(document).ready(function(){  
      $('#addNewMember').click(function(){  
           $('#btnAddMember').val("Add Member");  
           $('#addmember_form')[0].reset();  
      });  
      $(document).on('click', '.edit_data', function(){  
           var member_id = $(this).attr("id");  
           $.ajax({  
                url:"app/members/fetch.php",  
                method:"POST",  
                data:{member_id:member_id},  
                dataType:"json",  
                success:function(data){  
                     $('#staffno').val(data.staff_id);  
                     $('#ippisno').val(data.ippis_no);  
                     $('#firstname').val(data.firstname);  
                     $('#surname').val(data.surname);  
                     $('#othername').val(data.othername);  
                     $('#gender').val(data.gender);   
                     $('#phoneno').val(data.phoneno);  
                     $('#email').val(data.email);    
                     $('#selectpicker').val(data.dept_id);  
                     $('#member_id').val(data.id);  
                     $('#btnAddMember').val("Update");  
                     $('#membersModal').modal('show');  
                }  
           });  
      });  
      $('#addmember_form').on("submit", function(event){  
           event.preventDefault();  
           if($('#ippisno').val() == '')  
           {  
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('IPPIS number is required');
           } 
           else if($('#firstname').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Surname is required'); 
           } 
           else if($('#surname').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Gender is required'); 
           }
		   else if($('#email').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Email is required'); 
           } 
		   else if($('#department').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Department is required'); 
           } 
           else  
           {  
                $.ajax({  
                     url:"app/members/insert.php",  
                     method:"POST",  
                     data:$('#addmember_form').serialize(),  
                     beforeSend:function(){  
                          $('#btnAddMember').val("Saving...");  
                     },  
                     success:function(data){  
                          $('#addmember_form')[0].reset();  
                          $('#membersModal').modal('hide');  
                          $('#member_table').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', '.view_data', function(){  
           var member_id = $(this).attr("id");  
           if(member_id != '')  
           {  
                $.ajax({  
                     url:"app/members/select.php",  
                     method:"POST",  
                     data:{member_id:member_id},  
                     success:function(data){  
                          $('#member_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });

      $(document).on('click', '.delete_data', function(){  
           var member_id = $(this).attr("id");  
           if(member_id != '')  
           {  
                $.ajax({  
                     url:"app/members/delete.php",  
                     method:"POST",  
                     data:{member_id:member_id},  
                     success:function(data){  
                          $('#employee_list').html(data);  
                          //$('#dataModal').modal('show');  
                     }  
                });  
           }            
      });

       $("#membersModal").modal({
        show: false,
        backdrop: 'static'
    });  
 
     $('.members_list').DataTable();
 });  
 </script>
 <script type="text/javascript">
    var $modal= $('.new-member-modal');

    $('.target-member').on('click', function (e) {
        $modal.css({top: e.clientY, left: e.clientX, transform: 'scale(0.1, 0.1)'});
        $modal.modal('show');
        $modal.css({top: '', left: '', transform: ''});
    });

    $modal.on('hide', function () {    
        $modal.css({top: 0, left: 0, transform: 'scale(0.1, 0.1)', opacity:'0'});
        return false;    // uncomment this line to see zoom out
    });
    

    $modal.on('hidden', function () {
        $modal.css({top: '', left: '', transform: '', opacity:''});
    });


 </script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.selectpicker').selectpicker();
  })
</script>
<script type="text/javascript">
 function checkall(){
 	document.getElementById('select-all').onclick = function() {
  var checkboxes = document.getElementsByName('single_select');
  for (var checkbox of checkboxes) {
    checkbox.checked = this.checked;
  }
}
 }
</script>
<script type="text/javascript">
	 //this function getting list of staffs
	 	// 	var beforeSend = function(){
			// 		  $('#h_loader').css("display","block");
			// }

			 function loadStaffList() {
                  var xhttp = new XMLHttpRequest();
                  var dept = document.getElementById("selectpicker").value;
                  var payslpmonth = document.getElementById("payslpmonth").value;
               xhttp.onreadystatechange = function() {
                 if (this.readyState == 4 && this.status == 200) {
                  document.getElementById("loadstafflist").innerHTML = this.responseText;
                  checkall();
                  SendPayslip();
				  $('#employee_list').DataTable({ 
                      "destroy": true, //use for reinitialize datatable
					  "pageLength": 100
                   });
                 }
               };
               xhttp.open("GET", "app/members/getstafflist.php?dept="+dept+"&pslip="+payslpmonth, true);
              xhttp.send();
                
           }
         loadStaffList();    
//});
</script>

</body> 
</html>