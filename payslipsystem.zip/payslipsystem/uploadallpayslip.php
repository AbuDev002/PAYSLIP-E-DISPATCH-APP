<?php
	session_start();
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
			header('location:login.php');
	}
?>
<!Doctype html>
<html lang="en">
 <?php include_once('template/top-header.php');?>
 <body> <!-- onContextMenu="return false" -->
<?php include_once ('template/head.php')?>
<div class="container">
  <br/>
  <div class="row">
    <div class="col-md-9">
		<div class="card">
			  	<div class="card-header">
			    <p style="font-family: copper;">UPLOAD SPLITED PAYSLIP PDF FILES</p>
			  </div>
			  <div class="card-body">
			  	 <div class="row">
			  	 	<div class="col-md-10">
			  	 		<center><div id="error" class="error"><?php if(isset($statusMsg)){ echo $statusMsg; }?></div></center>

					<form method="post" id="upload_multiple_payslips" class="form-inline" enctype="multipart/form-data">
					  <div class="form-group">
					  	 <input type="month" class="form-control" name="payslipmonth">
					  </div>
					  &nbsp;&nbsp;&nbsp;
					  <div class="form-group">
					    <input type="file" name="pfiles[]" id='pfiles' class="form-control-file" multiple> <!-- accept=".jpg, .png, .gif, .pdf" -->
					  </div>
					  <div class="form-group">
					  <input type="submit" name="insert" class="btn btn-success btn-sm" id="insert" value='Upload'>
					</div>
					</form>
					
					
			  	 	</div>
			  	 	<div class="col-md-2">
			  	 		<div class="spinner-border text-success" id="spinner" role="status" style="display:none;">
					  <span class="sr-only">Loading...</span>
					</div>
			  	 	</div>
			  	 </div>
			  </div>
		</div>
	</div>
		<?php include_once('template/menu.php')?>
  </div>
		
</div>
<?php include_once('template/footer.php')?>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script>  
$(document).ready(function(){
    $('#upload_multiple_payslips').on('submit', function(event){
        event.preventDefault();
        var payslip_name = $('#pfiles').val();
        if(payslip_name == '')
        {
            $("#error").html('<div class="alert alert-danger">Please select files</div>');
            return false;
        }
        else
        {
        	$("#spinner").css({"display":"block"});
            $.ajax({
                url:"payslipfileupload.php",
                method:"POST",
                data: new FormData(this),
                contentType:false,
                cache:false,
                processData:false,
                success:function(data)
                {
                   if(data == "ok"){
		              setTimeout(function () {
                     	$('#pfiles').val('');
		                $("#spinner").css({"display":"none"});
		                   	$("#error").html('<div class="alert alert-success">Paysilp files successfully</div>');
                     },2000);
					}
					  else
					{
						$("#spinner").css({"display":"none"});
						$("#error").html('<div class="alert alert-danger">Unable to upload payslips. Please try again...</div>');
					  }
	                   	
	                }
            });
        }
    });
 
});  
</script>

</body> 
</html>