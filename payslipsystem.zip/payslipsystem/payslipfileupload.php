<?php 
//if(isset($_POST['insert'])){ 
    // Include the database configuration file 
    include_once 'connection.php'; 
    # Get file month
    @$filemonth = $_POST['payslipmonth'];
    // File upload configuration 
    $targetDir = "slipuploads/uploads/".$filemonth; 
    $allowTypes = array('jpg','png','jpeg','gif','pdf'); 
    //@$watermarkImagePath = 'images/watermarkheader.png';
     
    $statusMsg = $errorMsg = $insertValuesSQL = $errorUpload = $errorUploadType = ''; 
    
    @$fileNames = array_filter($_FILES['pfiles']['name']); 
    // if(!empty($fileNames)){ 
    # create directory if not exists in upload/ directory
      if(!is_dir($targetDir)){
        mkdir($targetDir, 0755);
      }
        foreach(@$_FILES['pfiles']['name'] as $key=>$val){ 
            // File upload path 
            $fileName = basename($_FILES['pfiles']['name'][$key]); 
            $targetFilePath = $targetDir."/". $fileName; 
             
            // Check whether file type is valid 
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION); 
            if(in_array($fileType, $allowTypes)){ 

                // Upload file to server 
                if(move_uploaded_file($_FILES["pfiles"]["tmp_name"][$key], $targetFilePath)){ 
                    // Image db insert sql 
                    $insertValuesSQL .= "('".$fileName."','".$filemonth."', NOW()),";
                            
                //This page contains edit the existing file by using fpdi.
                require_once('WatermarkPDF/WatermarkPDF.php');
                    $watermarkText = "Supported By: ICT/MIS Directorate FPTB";
                    $pdf = new WatermarkPDF($targetFilePath, $watermarkText);
                    //$pdf = new FPDI();
                    $pdf->AddPage();
                    $pdf->SetFont('Arial', '', 12);
                    if($pdf->numPages>1) {
                        for($i=2;$i<=$pdf->numPages;$i++) {
                            //$pdf->endPage();
                            $pdf->_tplIdx = $pdf->importPage($i);
                            $pdf->AddPage();
                        }
                    }

                    $pdf->Output($targetFilePath,'F'); //If you Leave blank then 
                }else{ 
                    $errorUpload .= $_FILES['pfiles']['name'][$key].' | '; 
                } 
            }else{ 
                $errorUploadType .= $_FILES['pfiles']['name'][$key].' | '; 
            } 
        } 
         
        if(!empty($insertValuesSQL)){ 
            $insertValuesSQL = trim($insertValuesSQL, ','); 
            // Insert image file name into database 
            $insert = mysqli_query($connect,"INSERT INTO tbl_payslip_upload (payslip_files,payslip_month, uploaded_on) VALUES $insertValuesSQL"); 
            if($insert){ 
                $errorUpload = !empty($errorUpload)?'Upload Error: '.trim($errorUpload, ' | '):''; 
                $errorUploadType = !empty($errorUploadType)?'File Type Error: '.trim($errorUploadType, ' | '):''; 
                $errorMsg = !empty($errorUpload)?'<br/>'.$errorUpload.'<br/>'.$errorUploadType:'<br/>'.$errorUploadType; 
                $statusMsg = "ok";//.$errorMsg; 
            }else{ 
                $statusMsg = "failed"; 
            } 
        } 
    // }else{ 
    //     $statusMsg = 'Please select a file to upload.'; 
    // } 
     echo $statusMsg;
//} 
?>