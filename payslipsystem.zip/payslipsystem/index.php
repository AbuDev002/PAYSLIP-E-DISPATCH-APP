<!doctype html>
<html lang="en">
  <?php include_once ('template/top-header.php')?>
 <body onload="update()">
	<nav class="navbar navbar-expand-sm " style="border-bottom:0px;background-color:#F7F7F7;">
		<!-- <ul class="navbar-nav ml-auto">
			<li class="nav-item">
				<a class="nav-link login" href="login.php">Login</a>
			</li>
		</ul> -->
	</nav>
		<div class="card text-center" style="border-top:0px;">
			<?php include_once ('template/head.php')?>
			<div class="card-body">
    			<center><p><img src="images/polylogo.jpg" class="d-block w-1000" alt="..." height="350"></p></center>
			</div>
  		</div>
  		<div class="container">
		  <div class="row">
		    <div class="col-sm-2">
		    </div>
		    <div class="col-sm-8">
		    	<br>
		      	<div class="progress">
				  <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar"
				  aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="myprogressBar">
				  </div>
				</div>
		    </div>
		    <div class="col-sm-2">
		    </div>
		  </div>
		</div>
  		<br>
  		<?php
			// if (!extension_loaded('imagick')){
			//     echo 'imagick not installed';
			// }else{
			// 	 echo 'installed';
			// }
  		?>
	<footer class="footer mt-auto py-3"  style="background: #F0F0F0;">
		<div class="container">
			<center><p class="text-muted">Copyright &copy; 2020: All Rights</p></center>
		</div>
	</footer>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript">
		function update() { 
		  var element = document.getElementById("myprogressBar");    
		  var width = 1; 
		  var identity = setInterval(scene, 90); 
		  function scene() { 
		    if (width >= 100) { 
		      clearInterval(identity); 
		      window.location.href="login.php";
		    } else { 
		      width++;  
		      element.style.width = width + '%';  
		    } 
		  } 
		} 
	</script>
</body>
</html>
