<?php
include_once("PdfToText/PdfToText.phpclass");
$pdf =  new PdfToText('paysliplist.pdf');
$string = "Staff ID";
$data = $pdf->Text;
 if(strpos($data, $string) !== false){
 	echo $string;
 }else{
 	echo "failed to search";
 }



?>
