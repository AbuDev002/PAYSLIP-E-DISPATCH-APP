<?php
//send_mail.php

if(isset($_POST['email_data']))
{
	require 'email_class/class.phpmailer.php';
	$output = '';
	foreach($_POST['email_data'] as $row)
	{
		$originalDate = $row["pmonth"];
		$newDate = date("F-Y", strtotime($originalDate));
		$mail = new PHPMailer;
		$mail->IsSMTP();								//Sets Mailer to send message using SMTP
		$mail->SMTPKeepAlive = true;
		$mail->Mailer = "smtp";
		//$mail->SMTPDebug  = 3;
		$mail->SMTPAuth = TRUE;							//Sets SMTP authentication. Utilizes the Username and Password variables
		$mail->Host = 'smtp.gmail.com';		//Sets the SMTP hosts of your Email hosting, this for Godaddy
		$mail->Username = 'salariesandwages@fptb.edu.ng';					//Sets SMTP username
		$mail->Password = 'salariesandwages@fptb';					//Sets SMTP password
		$mail->SMTPSecure = 'ssl';							//Sets connection prefix. Options are "", "ssl" or "tls"
		$mail->Port = 465;								//Sets the default SMTP server port
		$mail->From = 'salariesandwages@fptb.edu.ng';			//Sets the From email address for the message
		$mail->FromName = 'SALARIES AND WAGES UNIT BURSARY DEPARTMENT FPTB';					//Sets the From name of the message
		$mail->AddAddress($row["email"], $row["name"]);	//Adds a "To" address
		$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
		//Provide file path and name of the attachments
		$mail->addAttachment('slipuploads/uploads/'.$row["pmonth"].'/'.$row["payslip"]);//
		$mail->IsHTML(true);							//Sets message type to HTML
		$mail->Subject = 'PAYSLIP-MONTH OF '.$newDate; //Sets the Subject of the message
		//An HTML or plain text message body
		$mail->Body = ' Dear '.ucwords(strtolower($row['name'])).',
		<p>Please find attached your payment slip for the month of '.$newDate.'</p>
		<p>Regards.</p>
		';

		$mail->AltBody = '';

		$result = $mail->Send();						//Send an Email. Return true on success or false on error

		if(isset($result["code"]) == '400')
		{
			$output .= html_entity_decode($result['full_error']);
		}

	}
	if($output == '')
	{
		echo 'ok';
	}
	else
	{
		echo $output;
	}
}

?>