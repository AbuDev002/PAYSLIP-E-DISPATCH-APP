<?php 
		$connect=mysqli_connect('localhost','root','','payslipapp');
			//if(!$connect){
				//echo "there is error with database connection. Please verify";
			//}
			
?>