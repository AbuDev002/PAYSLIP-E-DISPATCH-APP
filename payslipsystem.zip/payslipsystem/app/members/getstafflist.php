<button type="button" name="bulk_email" class="btn btn-info btn-block email_button" id="bulk_email" data-action="bulk"><i class="fa fa-send-o"></i> Send Payslip</button>
<hr>
<form method="POST">
<div id="member_table" style="width:100%;overflow:auto;height:400px;"> 
<table id="employee_list" style="width:100%;font-size:14px;" class="table table-striped table-bordered animate__animated animate__zoomIn">
<thead>
	<tr>
		<th style="width:20px;">S/N</th>
		<th style="width:80px;">IPPIS No.</th>
		<th>Staff Name</th>
		<th>Email</th>
		<th><input type="checkbox" name="" id="select-all"> All</th>
		
		<th></th>
		<th></th>
		<th></th>
	</tr>
</thead>
<tbody>
<?php
if(isset($_GET["dept"]) AND isset($_GET["pslip"]))  
 { 
 @$getdept = strip_tags($_GET["dept"]); 
 @$payslipmonth = strip_tags($_GET["pslip"]); 
include_once('../../connection.php');
$count = 0;
$query = "SELECT * FROM employees LEFT JOIN tbl_payslip_upload ON employees.ippis_no= REGEXP_REPLACE(tbl_payslip_upload.payslip_files, '.pdf', '') WHERE payslip_month ='".$payslipmonth."' AND dept_id=".$getdept."";
$statement = mysqli_query($connect,$query);	
if(@$result = mysqli_num_rows($statement) > 0){
	while(@$row = mysqli_fetch_array($statement))
	{
		$count = $count + 1;
		echo '

		<tr>
			<td>'.$count.'</td>
			<td>'.$row["ippis_no"].'</td>
			<td>'.$row["surname"].' '.$row["firstname"].' '.$row["othername"].'</td>
			<td>'.$row["email"].'</td>
			
			<td>
		<input type="checkbox" name="single_select" class="single_select" data-email="'.$row["email"].'" data-name="'.$row["surname"].'" data-payslip="'.$row["payslip_files"].'" data-pmonth="'.$row["payslip_month"].'" />
			</td>
			<td><button type="button" name="edit" id="'.$row["id"].'" class="btn btn-info btn-xs edit_data target-member"><i class="fa fa-edit"></i></button></td>  
            <td><button type="button" name="view" id="'.$row["id"].'" class="btn btn-info btn-xs view_data"><i class="fa fa-eye"></i></button></td>
             <td><button type="button" name="view" id="'.$row["id"].'" class="btn btn-danger btn-xs delete_data"><i class="fa fa-trash"></i></button></td>
			
			
		</tr>
		';
	} 
	}
	else
	{
		echo "<center><div class='alert alert-info'>No record available</div></center>";
	}
 
}else{
	header("Location:employee.php");
}
?>
</tbody>
</table>
</div>
</form>