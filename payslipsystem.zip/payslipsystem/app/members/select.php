<?php  
 if(isset($_POST["member_id"]))  
 {  
      $output = '';  
      include_once('../../connection.php');  
      $query = "SELECT * FROM employees WHERE id = '".$_POST["member_id"]."'";  
      $result = mysqli_query($connect, $query);  
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td width="30%"><label>Staff PFN</label></td>  
                     <td width="70%">'.$row["staff_id"].'</td>  
                </tr>
                <tr>  
                     <td width="30%"><label>IPPIS No.</label></td>  
                     <td width="70%">'.$row["ippis_no"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Firstname</label></td>  
                     <td width="70%">'.$row["firstname"].'</td>  
                </tr> 
                 <tr>  
                     <td width="30%"><label>Surname</label></td>  
                     <td width="70%">'.$row["surname"].'</td>  
                </tr>
                 <tr>  
                     <td width="30%"><label>Othername</label></td>  
                     <td width="70%">'.$row["othername"].'</td>  
                </tr>   
                <tr>  
                     <td width="30%"><label>Email</label></td>  
                     <td width="70%">'.$row["email"].'</td>   
                </tr>
                <tr>  
                     <td width="30%"><label>Phone</label></td>  
                     <td width="70%">'.$row["phoneno"].'</td>   
                </tr>  
                <tr>  
                     <td width="30%"><label>Gender</label></td>  
                     <td width="70%">'.$row["gender"].'</td>  
                </tr>
                <tr>  
                     <td width="30%"><label>Department</label></td>  
                     <td width="70%">'.$row["dept_id"].'</td>  
                </tr>   
               
           ';  
      }  
      $output .= '  
           </table>  
      </div>  
      ';  
      echo $output;  
 }  
 ?>