 <?php  
 //fetch.php  
include_once('../../connection.php');  
 if(isset($_POST["member_id"]))  
 {  
 	   $output = '';
      $count =0;  
      $message = '';

      $query = "DELETE FROM employees WHERE id = ".$_POST["member_id"]."";  
      $message = '<p class="text-success">Member Data Deleted</p>';  
      if(mysqli_query($connect, $query))  
      { 
      	 $count = $count + 1;
           $output .= '<label class="text-success">' . $message . '</label>';  
           $select_query = "SELECT * FROM employees LEFT JOIN tbl_payslip_upload ON employees.ippis_no= REGEXP_REPLACE(tbl_payslip_upload.payslip_files, '.pdf', '')"; 
           $result = mysqli_query($connect, $select_query);
      	$output .= '
                <div id="member_table">   
                <table class="table table-bordered table-striped table-responsive members_list" style="font-size:14px;">   
                     <thead>
                          <tr>
                          <th style="width:80px;">Staff ID</th>
                          <th style="width:80px;">IPPIS No.</th>
                          <th>Staff Name</th>
                          <th>Email</th>
                          <th colspan="2"></th>
                          <th><input type="checkbox" name="" id="select-all"> All</th>
                          <th>Action</th>
                        </tr>
                        </thead>
                    <tbody> 
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["staff_id"] . '</td>  
                          <td>' . $row["ippis_no"] . '</td>  
                          <td>' . $row["surname"] . ' '.$row["firstname"].' '.$row["othername"].'</td>  
                          <td>' . $row["email"] . '</td>
                          <td>
            <button type="button" name="email_button" class="btn btn-info btn-xs email_button" id="'.$count.'" data-email="'.$row["email"].'" data-name="'.$row["surname"].'" data-payslip="'.$row["payslip_files"].'" data-action="single"><i class="fa fa-send"></i></button>
            </td>  
                          <td><button type="button" name="edit" id="'.$row["id"].'" class="btn btn-info btn-xs edit_data target-member"><i class="fa fa-edit"></i></button></td>  
	                    <td><button type="button" name="view" id="'.$row["id"].'" class="btn btn-info btn-xs view_data"><i class="fa fa-eye"></i></button></td>
	                     <td><button type="button" name="view" id="'.$row["id"].'" class="btn btn-danger btn-xs delete_data"><i class="fa fa-trash"></i></button></td>
						<td>
          <input type="checkbox" name="single_select" class="single_select" data-email="'.$row["email"].'" data-name="'.$row["surname"].'" data-payslip="'.$row["payslip_files"].'" />
            </td>
              
                     </tr>  
                ';  
           }  
           $output .= '</tbody> </table></div>';  
      }  
      	echo $output;
 	 }  
 ?>