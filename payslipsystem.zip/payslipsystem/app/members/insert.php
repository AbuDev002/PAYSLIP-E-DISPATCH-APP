 <?php  
 include_once('../../connection.php');   
 if(!empty($_POST))  
 {  
      $output = '';
      $count =0;  
      $message = '';  
      $staffno = mysqli_real_escape_string($connect, $_POST["staffno"]);  
      $ippisno = mysqli_real_escape_string($connect, $_POST["ippisno"]);  
      $firstname = mysqli_real_escape_string($connect, $_POST["firstname"]);  
      $surname = mysqli_real_escape_string($connect, $_POST["surname"]);  
      $othername = mysqli_real_escape_string($connect, $_POST["othername"]);  
      $gender = mysqli_real_escape_string($connect, $_POST["gender"]);  
      $phoneno = mysqli_real_escape_string($connect, $_POST["phoneno"]);  
      $email = mysqli_real_escape_string($connect, $_POST["email"]);  
      $department = mysqli_real_escape_string($connect, $_POST["department"]);  
      if(@$_POST["member_id"] != '')  
      {  
           $query = "  
           UPDATE employees   
           SET 
           staff_id='$staffno',   
           ippis_no='$ippisno',   
           firstname='$firstname',   
           surname='$surname',   
           othername='$othername',   
           gender='$gender',    
           phoneno = '$phoneno',   
           email = '$email',   
           dept_id = '$department'   
           WHERE id=".$_POST["member_id"]."";  
           $message = '<p class="text-success">Member Data Updated</p>';  
      }  
      else  
      {  
           $query = "  
           INSERT INTO employees (staff_id,ippis_no, surname, firstname, othername, gender,phoneno,email,dept_id)  
           VALUES('$staffno','$ippisno', '$surname', '$firstname', '$othername', '$gender', '$phoneno', '$email', '$department');  
           ";  
           $message = '<p class="text-success">New Staff Added Successfully</p>';  
      }  
      if(mysqli_query($connect, $query))  
      {  
           $output .= '<label class="text-success">' . $message . '</label>';  
      }  
      echo $output;  
 }  
 ?>