<?php
	session_start();
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
			header('location:login.php');
	}
?>
<!doctype html>
<html lang="en">
 <?php include_once('template/top-header.php');?>
 <body>
<?php include_once ('template/head.php')?>
<div class="container">
  <br/>
  <div class="row">
    <div class="col-md-9"style= "borde-top: 0px;">
		<div class="col-sm-12">
			<div class="card-body">
				<div class="jumbotron jumbotron">
					<div class="container">
						<h5 class="display-6">FPTB PAYSLIP E-DISPATCH SYSTEM</h5>
						<p class="lead">This application is designed to send IPPIS generated payment slip to staff email addresses, staff can print their payslip at anytime.</p>
					</div>
				</div>
				
			</div>
		</div>
		 <!--<p style="text-align: center;"><small>&copy; 2020 | ICT/MIS Directorate, FPTB</small> </p>-->
		<?php include_once('template/footer.php')?>
	</div>
  <?php include_once('template/menu.php')?>
  </div>
  <!-- <footer >
 
</footer> -->
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
 <script src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
 <script src="js/bootstrap-select.min.js"></script>
<script src="js/alertify.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="js/responsive.bootstrap4.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.selectpicker').selectpicker();
	
  })
</script>

</body> 
</html>