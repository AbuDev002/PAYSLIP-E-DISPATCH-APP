<?php 
$uploadDir = 'slipuploads/'; 
$response = array( 
    'status' => 0, 
    'message' => 'Form submission failed, please try again.' 
); 
 
// If form is submitted 
if(isset($_POST['date_name']) || isset($_POST['payslip_file'])){ 
    // Get the submitted form data 
    $date_name = $_POST['date_name']; 
     
    // Check whether submitted data is not empty 
    if(!empty($date_name)){ 
            $uploadStatus = 1; 
             
            // Upload file 
            $uploadedFile = ''; 
            if(!empty($_FILES["payslip_file"]["name"])){ 
                 
                // File path config 
                $fileName = basename($_FILES["payslip_file"]["name"]); 
                $targetFilePath = $uploadDir . $fileName; 
                $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION); 
                 
                // Allow certain file formats 
                $allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg'); 
                if(in_array($fileType, $allowTypes)){ 
                    // Upload file to the server 
                    if(move_uploaded_file($_FILES["payslip_file"]["tmp_name"], $targetFilePath)){ 
                        $uploadedFile = $fileName; 
                    }else{ 
                        $uploadStatus = 0; 
                        $response['message'] = 'Sorry, there was an error uploading your file.'; 
                    } 
                }else{ 
                    $uploadStatus = 0; 
                    $response['message'] = 'Sorry, only PDF, DOC, JPG, JPEG, & PNG files are allowed to upload.'; 
                } 
            }else{
                $uploadStatus = 0; 
                    $response['message'] = 'You need to select payslip file and date'; 
            } 
             
            if($uploadStatus == 1){ 
                // Include the database config file 
                include_once 'connection.php'; 
                 
                // Insert form data in the database 
                $insert = mysqli_query($connect,"INSERT INTO payslip_report (payslip_name,payslip_date) VALUES ('".$uploadedFile."','".$date_name."')"); 
                 
                if($insert){ 
                    $response['status'] = 1; 
                    $response['message'] = 'Payslip uploaded successfully!'; 
                } 
            } 
        
    }else{ 
         $response['message'] = 'Please fill all the mandatory fields (name and email).'; 
    } 
} 
 
// Return response 
echo json_encode($response);
?>